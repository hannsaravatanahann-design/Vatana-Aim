# Skypix: AI Photo Enhancer 🇰🇭

Next.js 14 + React + TypeScript + Tailwind. Upload → choose size → AI enhance → compare → save. No accounts.

## Provider: Replicate (nightmareai/real-esrgan)
| Why | Notes |
|---|---|
| Real upscaler + optional GFPGAN face restoration | Async jobs: the app starts a prediction and polls it |
| Simple REST API, pay-per-use, no subscription | No free enhancement is advertised. New accounts may get limited trial credit; check current terms |
| Cost | Billed by GPU time per run, so larger inputs and `scale` cost more. Check replicate.com/pricing and the model page for current numbers |
| Limits | Max scale per pass is 4. Inputs are reduced to 1600 px on the long edge to protect GPU memory |
| Retention | Replicate documents deleting API prediction files after about an hour. Verify before launch |

Other candidates worth comparing: Stability AI upscale endpoints, Deep-Image.ai, Topaz API. Check each one's commercial-use terms, resolution caps and retention. Swap providers by implementing `EnhanceProvider` in `lib/provider.ts`.

## How 8K really works
The AI upscales up to ×4 (output ≈ 6400 px long edge from the 1600 px input). For sizes beyond that (e.g. 8K from a small photo) the last step is a Lanczos resample to the exact target. The app shows this in the result note. Settings the provider does not support (noise reduction, sharpening, colour correction) are intentionally **not** offered.

## Setup
```bash
npm install
cp .env.example .env.local   # add your Replicate token as AI_PROVIDER_API_KEY
npm run dev                  # http://localhost:3000
```
Without a key, enhancing returns a clear error. No simulated results.

## Deploy
Use a Node host with no small response-body cap (Railway, Render, Fly.io, a VPS, Docker). Large 4K/8K results are many MB, and serverless platforms such as Vercel cap function responses (~4.5 MB). Put it behind HTTPS (the app sends HSTS). Set the env vars on the host. For several instances, replace the in-memory rate limiter in `lib/security.ts` with Redis.

## Security
Key stays server-side; upload size and real file-signature checks; pixel limit; per-IP rate limit and daily job cap; nothing written to disk.

## Saving
iPhone/iPad: Web Share with the real file (choose Save Image), with a press-and-hold fallback. Android/desktop: download as `skypix-enhanced.png|jpg` (PNG up to ~2.7 MP, JPEG q92 above, extension matches actual type). Browsers cannot silently write to the iPhone Photos library.

## Known gaps
Not run or type-checked in the build environment (no network). Run `npm install && npm run lint && npm run build` first. Hero art is original SVG; swap in photography/statue renders as desired.

---
# v2: Google sign-in, admin dashboard, creator credit

**Stack added:** Auth.js v5 (`next-auth@beta`, JWT cookie sessions, 7 days) and SQLite via `better-sqlite3`.
**Guests still work.** Enhancement needs sign-in only if `REQUIRE_SIGN_IN=true` or the admin toggles it in /admin → Settings.

## Google OAuth setup
1. Go to console.cloud.google.com → create a project.
2. *APIs & Services → OAuth consent screen*: choose External, enter app name (Skypix), support email, and developer email. Scopes: only `openid`, `email`, `profile` (no Google verification review needed for these).
3. *Credentials → Create credentials → OAuth client ID → Web application*.
   - Authorized JavaScript origins: `http://localhost:3000` and `https://YOUR-DOMAIN`
   - Authorized redirect URIs: `http://localhost:3000/api/auth/callback/google` and `https://YOUR-DOMAIN/api/auth/callback/google`
4. Copy the client ID and secret into `.env.local` as `AUTH_GOOGLE_ID` / `AUTH_GOOGLE_SECRET`. Generate `AUTH_SECRET` with `openssl rand -base64 32`.
5. Local test: `npm run dev`, open http://localhost:3000, click Sign in with Google. While the consent screen is in **Testing**, only listed test users can sign in (add your Google accounts there).
6. Production: set the same variables on the host, set `AUTH_URL=https://YOUR-DOMAIN`, serve over HTTPS, then *OAuth consent screen → Publish app* so anyone can sign in.

If you can't access saravatanahann@gmail.com, use Google's account recovery at accounts.google.com/signin/recovery. There is no password or backdoor in Skypix.

## Admin access
`ADMIN_EMAILS` (comma-separated, case-insensitive) is compared on the server with the email Google verified (`email_verified` must be true or sign-in is refused). `/admin` and every `/api/admin/*` call re-check this on the server; writes also require a same-origin request. Add more admins by adding emails to the variable.

## Database
SQLite file at `DATABASE_PATH` (users, job records, settings; no photos, no passwords, no tokens). It is free but needs a **persistent disk** (Railway/Render/Fly volume or a VPS). It will not persist on Vercel-style serverless. Backups are your responsibility. Moving to Postgres/Turso is possible but not included.

## Testing checklist (not run by the author, run these yourself)
1. Sign in with Google works → name/picture appear; Sign out ends the session.
2. Admin email → "Admin Dashboard" link and /admin loads.
3. Other Google account → no link; /admin shows "Access denied".
4. Signed out: /admin redirects to /signin; `curl -i localhost:3000/api/admin/users` → 401; with a normal user's cookie → 403.
5. Cancel on Google's screen → /signin shows an error message.
6. Upload → enhance → compare → save still work (needs a Replicate key); test on iPhone Safari.
7. Admin → Settings: toggle "Require sign-in" and confirm a guest sees the sign-in prompt.

## Files changed
New: `auth.ts`, `lib/db.ts`, `lib/session.ts`, `app/signin/page.tsx`, `app/admin/page.tsx`, `app/api/auth/[...nextauth]/route.ts`, `app/api/admin/[section]/route.ts`, `components/{AuthMenu,SignInButton,AdminDashboard}.tsx`.
Edited: `package.json`, `next.config.mjs`, `.env.example`, `.gitignore`, `lib/security.ts`, `app/api/enhance/route.ts`, `app/api/enhance/[id]/route.ts`, `app/page.tsx`, `app/legal/page.tsx`, `components/Nav.tsx`, `components/Enhancer.tsx`, `README.md`.
