/** @type {import('next').NextConfig} */
export default {
  poweredByHeader: false,
  experimental: { serverComponentsExternalPackages: ['sharp', 'better-sqlite3'] },
  async headers() {
    return [{ source: '/(.*)', headers: [
      { key: 'X-Content-Type-Options', value: 'nosniff' },
      { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
      { key: 'Strict-Transport-Security', value: 'max-age=63072000; includeSubDomains' },
    ] }];
  },
};
