import NextAuth from 'next-auth';
import Google from 'next-auth/providers/google';
import { upsertUser } from '@/lib/db';

/** Server-side allowlist, normalised (trim + lowercase). Compared only against the Google-verified email. */
export const isAdminEmail = (email?: string | null) =>
  !!email && (process.env.ADMIN_EMAILS ?? '').split(',').map((e) => e.trim().toLowerCase()).filter(Boolean).includes(email.trim().toLowerCase());

export const { handlers, auth, signIn, signOut } = NextAuth({
  providers: [Google({ authorization: { params: { scope: 'openid email profile' } } })], // reads AUTH_GOOGLE_ID / AUTH_GOOGLE_SECRET
  session: { strategy: 'jwt', maxAge: 60 * 60 * 24 * 7 },
  pages: { signIn: '/signin', error: '/signin' },
  callbacks: {
    async signIn({ account, profile }) {
      if (account?.provider !== 'google' || !profile?.sub || !profile.email || profile.email_verified !== true) return false;
      const row = upsertUser(profile.sub, profile.email.toLowerCase(), profile.name ?? null);
      return !(row.blocked && !isAdminEmail(profile.email)); // restricted accounts cannot sign in (admins can't lock themselves out)
    },
    async jwt({ token, profile }) {
      if (profile?.sub) { token.uid = profile.sub; token.email = profile.email?.toLowerCase(); }
      return token;
    },
    async session({ session, token }) {
      (session.user as { id?: string }).id = token.uid as string | undefined;
      return session;
    },
  },
});
