import type { Config } from 'tailwindcss';
export default {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: { extend: {
    colors: { ink: '#101114', panel: '#191A1F', gold: '#D9A441', gold2: '#F5D58A', sand: '#D7BD8A', cream: '#F5F0E6', mute: '#A8A8AD' },
    fontFamily: { display: ['var(--font-display)', 'serif'], body: ['var(--font-body)', 'system-ui', 'sans-serif'] },
  } },
  plugins: [],
} satisfies Config;
