export type ResKey = 'original' | '480p' | '720p' | '1080p' | '2k' | '4k' | '8k';
export const RESOLUTIONS: { key: ResKey; label: string; frame: [number, number] | null }[] = [
  { key: 'original', label: 'Original Quality', frame: null },
  { key: '480p', label: '480p', frame: [854, 480] },
  { key: '720p', label: '720p HD', frame: [1280, 720] },
  { key: '1080p', label: '1080p Full HD', frame: [1920, 1080] },
  { key: '2k', label: '2K', frame: [2560, 1440] },
  { key: '4k', label: '4K Ultra HD', frame: [3840, 2160] },
  { key: '8k', label: '8K Ultra HD', frame: [7680, 4320] },
];

/** Fits the photo inside the 16:9 reference frame (rotated for portrait photos), keeping its aspect ratio.
 *  A 16:9 photo gets exactly 3840x2160 for 4K and 7680x4320 for 8K. */
export function targetSize(w: number, h: number, key: ResKey) {
  const r = RESOLUTIONS.find((x) => x.key === key);
  if (!r || !r.frame) return { w, h };
  const [fw, fh] = w >= h ? r.frame : [r.frame[1], r.frame[0]];
  const s = Math.min(fw / w, fh / h);
  return { w: Math.max(1, Math.round(w * s)), h: Math.max(1, Math.round(h * s)) };
}
