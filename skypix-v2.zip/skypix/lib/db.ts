import Database from 'better-sqlite3';
import fs from 'node:fs';
import path from 'node:path';

let db: Database.Database | undefined;
export function getDb() {
  if (!db) {
    const file = process.env.DATABASE_PATH ?? './data/skypix.db';
    fs.mkdirSync(path.dirname(file), { recursive: true });
    db = new Database(file);
    db.pragma('journal_mode = WAL');
    db.exec(`
      CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY, email TEXT NOT NULL, name TEXT, created_at INTEGER NOT NULL, last_login INTEGER NOT NULL, blocked INTEGER NOT NULL DEFAULT 0);
      CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY, user_id TEXT, resolution TEXT NOT NULL, face INTEGER NOT NULL, status TEXT NOT NULL, error TEXT, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL);
      CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);`);
  }
  return db;
}
export function upsertUser(id: string, email: string, name: string | null) {
  const d = getDb(), now = Date.now();
  d.prepare(`INSERT INTO users(id,email,name,created_at,last_login) VALUES(?,?,?,?,?)
    ON CONFLICT(id) DO UPDATE SET email=excluded.email, name=excluded.name, last_login=excluded.last_login`).run(id, email, name, now, now);
  return d.prepare('SELECT blocked FROM users WHERE id=?').get(id) as { blocked: number };
}
export function isBlocked(id: string) {
  try { return !!(getDb().prepare('SELECT blocked FROM users WHERE id=?').get(id) as { blocked: number } | undefined)?.blocked; } catch { return false; }
}
// Recording must never break enhancement, so failures are swallowed.
export function recordJob(id: string, userId: string | null, resolution: string, face: boolean, status = 'processing', error?: string) {
  try { const n = Date.now(); getDb().prepare('INSERT OR IGNORE INTO jobs VALUES(?,?,?,?,?,?,?,?)').run(id, userId, resolution, face ? 1 : 0, status, error?.slice(0, 300) ?? null, n, n); } catch {}
}
export function finishJob(id: string, status: string, error?: string) {
  try { getDb().prepare("UPDATE jobs SET status=?, error=?, updated_at=? WHERE id=? AND status='processing'").run(status, error?.slice(0, 300) ?? null, Date.now(), id); } catch {}
}
export function getSetting(key: string) {
  try { return (getDb().prepare('SELECT value FROM settings WHERE key=?').get(key) as { value: string } | undefined)?.value; } catch { return undefined; }
}
export const setSetting = (key: string, value: string) => { getDb().prepare('INSERT INTO settings VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run(key, value); };
export const getNum = (key: string, def: number) => { const v = Number(getSetting(key)); return getSetting(key) !== undefined && Number.isFinite(v) ? v : def; };
export const getBool = (key: string, def: boolean) => { const v = getSetting(key); return v === undefined ? def : v === '1'; };
