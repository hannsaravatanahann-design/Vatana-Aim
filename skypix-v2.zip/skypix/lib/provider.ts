/**
 * Provider abstraction. To switch vendors, implement EnhanceProvider and return it from getProvider().
 * Current implementation: Replicate running nightmareai/real-esrgan (Real-ESRGAN upscaler, optional GFPGAN face restoration).
 */
export type JobState = 'processing' | 'succeeded' | 'failed';
export interface EnhanceOptions { scale: number; faceEnhance: boolean }
export interface EnhanceProvider {
  name: string;
  /** Capabilities the UI may expose. Anything not listed here is not offered. */
  capabilities: { faceRestoration: boolean; maxScalePerPass: number };
  start(image: Buffer, mime: string, o: EnhanceOptions): Promise<string>;
  status(id: string): Promise<{ state: JobState; outputUrl?: string; error?: string }>;
}
export class ProviderError extends Error {
  constructor(message: string, public status = 502, public retryable = true) { super(message); }
}

const API = 'https://api.replicate.com/v1';
const MODEL = 'nightmareai/real-esrgan';
let cachedVersion: string | undefined;

function headers() {
  const key = process.env.AI_PROVIDER_API_KEY;
  if (!key || key === 'your_api_key_here') throw new ProviderError('The server is missing its AI provider API key.', 503, false);
  return { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' };
}
async function call(path: string, init?: RequestInit) {
  let res: Response;
  try { res = await fetch(`${API}${path}`, { ...init, headers: headers(), signal: AbortSignal.timeout(30_000) }); }
  catch (e) { if (e instanceof ProviderError) throw e; throw new ProviderError('The AI provider did not respond in time.', 504); }
  if (res.status === 429) throw new ProviderError('The AI provider is busy. Please try again shortly.', 429);
  if (res.status === 401 || res.status === 402) throw new ProviderError('The AI provider rejected the account credentials or billing.', 503, false);
  if (!res.ok) throw new ProviderError(`The AI provider returned an error (${res.status}).`);
  try { return await res.json(); } catch { throw new ProviderError('The AI provider returned an unreadable response.'); }
}
async function version() {
  if (process.env.AI_MODEL_VERSION) return process.env.AI_MODEL_VERSION;
  if (cachedVersion) return cachedVersion;
  const m = await call(`/models/${MODEL}`);
  const v = m?.latest_version?.id;
  if (typeof v !== 'string') throw new ProviderError('Could not determine the model version.');
  return (cachedVersion = v);
}

const replicate: EnhanceProvider = {
  name: 'Replicate (Real-ESRGAN)',
  capabilities: { faceRestoration: true, maxScalePerPass: 4 },
  async start(image, mime, o) {
    const p = await call('/predictions', {
      method: 'POST',
      body: JSON.stringify({
        version: await version(),
        input: { image: `data:${mime};base64,${image.toString('base64')}`, scale: o.scale, face_enhance: o.faceEnhance },
      }),
    });
    if (typeof p?.id !== 'string') throw new ProviderError('The AI provider returned an invalid job.');
    return p.id;
  },
  async status(id) {
    const p = await call(`/predictions/${id}`);
    if (p.status === 'succeeded') {
      const out = Array.isArray(p.output) ? p.output[0] : p.output;
      if (typeof out !== 'string' || !out.startsWith('https://')) return { state: 'failed', error: 'The provider returned no image.' };
      return { state: 'succeeded', outputUrl: out };
    }
    if (p.status === 'failed' || p.status === 'canceled') return { state: 'failed', error: 'The AI provider could not process this photo. Try a smaller photo or turn off face restoration.' };
    return { state: 'processing' };
  },
};

export function getProvider(): EnhanceProvider {
  switch (process.env.AI_PROVIDER ?? 'replicate') {
    case 'replicate': return replicate;
    default: throw new ProviderError('Unknown AI_PROVIDER.', 500, false);
  }
}
