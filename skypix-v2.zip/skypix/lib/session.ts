import { auth, isAdminEmail } from '@/auth';
import { isBlocked } from '@/lib/db';

/** Server-side current user, re-checked against the DB so restrictions apply to existing sessions. */
export async function getUser() {
  const s = await auth();
  const id = (s?.user as { id?: string } | undefined)?.id;
  const email = s?.user?.email?.toLowerCase();
  if (!s?.user || !id || !email) return null;
  const isAdmin = isAdminEmail(email);
  if (!isAdmin && isBlocked(id)) return null;
  return { id, email, name: s.user.name ?? null, image: s.user.image ?? null, isAdmin };
}
