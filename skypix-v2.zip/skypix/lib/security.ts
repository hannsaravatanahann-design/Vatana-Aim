import type { NextRequest } from 'next/server';
import { getNum } from '@/lib/db';

// In-memory limiter: fine for one Node process. On multiple instances/serverless use Redis (e.g. Upstash).
const hits = new Map<string, number[]>();
let day = new Date().toDateString();
let jobsToday = 0;

export function clientIp(req: NextRequest) {
  return req.headers.get('x-forwarded-for')?.split(',')[0].trim() || 'unknown';
}
export function limited(key: string, max: number, windowMs = 600_000) {
  const now = Date.now();
  const list = (hits.get(key) ?? []).filter((t) => now - t < windowMs);
  if (list.length >= max) { hits.set(key, list); return true; }
  list.push(now); hits.set(key, list);
  return false;
}
export function dailyBudgetExceeded() {
  const today = new Date().toDateString();
  if (today !== day) { day = today; jobsToday = 0; }
  if (jobsToday >= getNum('max_jobs_per_day', Number(process.env.MAX_JOBS_PER_DAY ?? 300))) return true;
  jobsToday++;
  return false;
}
/** Checks real file signature, not just the declared MIME type. */
export function sniff(b: Buffer): 'image/jpeg' | 'image/png' | 'image/webp' | null {
  if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return 'image/jpeg';
  if (b.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'image/png';
  if (b.subarray(0, 4).toString() === 'RIFF' && b.subarray(8, 12).toString() === 'WEBP') return 'image/webp';
  return null;
}
