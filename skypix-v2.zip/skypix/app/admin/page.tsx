import { redirect } from 'next/navigation';
import Nav from '@/components/Nav';
import AuthMenu from '@/components/AuthMenu';
import AdminDashboard from '@/components/AdminDashboard';
import { getUser } from '@/lib/session';

export const dynamic = 'force-dynamic';
export const metadata = { title: 'Admin — Skypix', robots: { index: false } };

export default async function Admin() {
  const u = await getUser();
  if (!u) redirect('/signin?callbackUrl=%2Fadmin');
  return (
    <>
      <Nav auth={<AuthMenu />} />
      {u.isAdmin ? <AdminDashboard email={u.email} name={u.name} /> : (
        <main className="mx-auto max-w-md px-4 py-24 text-center">
          <h1 className="font-display text-4xl text-gold2">Access denied</h1>
          <p className="mt-3 text-mute">This area is only for the Skypix administrator. Your account ({u.email}) does not have access.</p>
          <a href="/" className="mt-6 inline-block rounded-xl bg-gold px-6 py-3 font-semibold text-ink">Back to Skypix</a>
        </main>
      )}
      <footer className="px-4 py-8 text-center text-xs text-gold/70">Created by Hann Saravatana</footer>
    </>
  );
}
