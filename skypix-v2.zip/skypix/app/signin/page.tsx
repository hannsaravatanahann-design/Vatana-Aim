import { redirect } from 'next/navigation';
import Nav from '@/components/Nav';
import AuthMenu from '@/components/AuthMenu';
import SignInButton from '@/components/SignInButton';
import { Logo } from '@/components/Logo';
import { getUser } from '@/lib/session';

export const dynamic = 'force-dynamic';
const safe = (s?: string) => (s && s.startsWith('/') && !s.startsWith('//') ? s : '/');
const errors: Record<string, string> = {
  AccessDenied: 'Sign-in was cancelled, Google did not confirm your email, or this account is restricted.',
  Configuration: 'Google sign-in is not configured on this server yet. The site owner needs to add the OAuth credentials.',
  Verification: 'That sign-in link is no longer valid. Please try again.',
};

export default async function SignIn({ searchParams }: { searchParams: { error?: string; callbackUrl?: string } }) {
  const to = safe(searchParams.callbackUrl);
  if (await getUser()) redirect(to);
  const err = searchParams.error && (errors[searchParams.error] ?? 'Sign-in did not complete. Please try again.');
  return (
    <>
      <Nav auth={<AuthMenu />} />
      <main className="khmer-pattern mx-auto grid max-w-md place-items-center px-4 py-16">
        <div className="w-full rounded-2xl border border-gold/30 bg-panel p-8 text-center">
          <div className="flex justify-center"><Logo size="lg" /></div>
          <h1 className="mt-6 font-display text-3xl text-gold2">Welcome to Skypix</h1>
          <p className="mt-2 text-sm text-mute">Google handles the sign-in. Skypix never sees your password and only receives your name, email and profile picture.</p>
          {err && <p role="alert" className="mt-4 rounded-lg border border-red-400/40 bg-red-950/40 p-3 text-sm text-red-200">{err}</p>}
          <div className="mt-6 flex justify-center"><SignInButton redirectTo={to} /></div>
          <a href="/" className="mt-5 inline-block text-sm text-mute hover:text-gold2">Continue as guest</a>
        </div>
      </main>
    </>
  );
}
