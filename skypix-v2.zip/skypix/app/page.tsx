import AuthMenu from '@/components/AuthMenu';
import SignInButton from '@/components/SignInButton';
import { getUser } from '@/lib/session';
import { getBool } from '@/lib/db';
import Nav from '@/components/Nav';
import Enhancer from '@/components/Enhancer';
import Demo from '@/components/Demo';
import { BayonFace, Sparkle, Temple } from '@/components/Logo';

const features = [
  ['AI upscaling', 'Real-ESRGAN rebuilds edges and texture as it enlarges your photo, instead of just stretching pixels.'],
  ['Face restoration', 'Optional GFPGAN pass that sharpens faces in portraits and old family photos.'],
  ['Sizes from 480p to 8K', 'Pick a size. The AI enlarges up to ×4; if 8K needs more, the last step is a standard resample, and Skypix tells you so.'],
  ['Optional Google sign-in', 'Sign in if you like. Skypix keeps only your name, email and job status, never your photos, and never uses them for training.'],
];

export const dynamic = 'force-dynamic';
export default async function Home() {
  const user = await getUser();
  const locked = !user && getBool('require_sign_in', process.env.REQUIRE_SIGN_IN === 'true');
  return (
    <>
      <Nav auth={<AuthMenu />} />
      <main>
        <section id="home" className="khmer-pattern relative overflow-hidden">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_50%_100%,rgba(217,164,65,.35),transparent_60%)]" />
          <div className="sandstone absolute inset-0" />
          <div className="dawn absolute inset-0 bg-gradient-to-r from-transparent via-gold2/20 to-transparent" />
          <Temple className="absolute inset-x-0 bottom-0 h-[60%] w-full text-[#08080a]" />
          <div className="relative mx-auto max-w-6xl px-4 pb-52 pt-16 sm:pt-24 sm:pb-64">
            <p className="flex items-center gap-2 text-sand"><Sparkle className="h-4 w-4" /> Restore Every Pixel. Reveal Every Detail.</p>
            <h1 className="mt-4 max-w-3xl font-display text-5xl font-semibold leading-[1.05] text-cream sm:text-7xl">Turn Low-Quality Photos Into Stunning Images.</h1>
            <p className="mt-5 max-w-xl text-lg text-mute">Restore details, sharpen images, reduce noise, and upscale your photos with AI. Experience the next generation of image enhancement, inspired by Cambodia.</p>
            <a href="#enhancer" className="mt-8 inline-flex min-h-12 items-center rounded-xl bg-gold px-7 font-semibold text-ink hover:bg-gold2">Enhance My Photo</a>
          </div>
        </section>

        <section id="enhancer" className="mx-auto max-w-5xl scroll-mt-20 px-4 py-16">
          <h2 className="mb-6 font-display text-4xl text-gold2">AI Enhancer</h2>
          <Enhancer locked={locked} signInSlot={<SignInButton redirectTo="/#enhancer" />} />
        </section>

        <section className="mx-auto max-w-3xl px-4 pb-16">
          <h2 className="mb-4 font-display text-3xl text-gold2">How enhancement looks</h2>
          <Demo />
        </section>

        <section id="features" className="mx-auto max-w-6xl scroll-mt-20 px-4 py-16">
          <h2 className="font-display text-4xl text-gold2">Features</h2>
          <dl className="mt-8 grid gap-x-10 gap-y-8 sm:grid-cols-2">
            {features.map(([t, d]) => <div key={t} className="border-l-2 border-gold/50 pl-4"><dt className="font-semibold text-cream">{t}</dt><dd className="mt-1 text-mute">{d}</dd></div>)}
          </dl>
        </section>

        <section id="about" className="khmer-pattern scroll-mt-20 border-y border-gold/15 bg-panel/60">
          <div className="mx-auto grid max-w-6xl items-center gap-10 px-4 py-16 md:grid-cols-[1fr_180px]">
            <div>
              <h2 className="font-display text-4xl text-gold2">About Skypix</h2>
              <p className="mt-4 max-w-2xl text-mute">Skypix pairs modern AI upscaling with the spirit of the Khmer builders who carved Angkor’s towers and the serene faces of the Bayon, work that rewards a closer look. Honest limits: AI can make a photo clearer, but it cannot bring back detail that was never captured.</p>
              <p className="mt-4 text-sm text-gold/70">Created by Hann Saravatana</p>
            </div>
            <BayonFace className="mx-auto w-36 md:w-full" />
          </div>
        </section>
      </main>
      <footer className="mx-auto flex max-w-6xl flex-wrap justify-between gap-3 px-4 py-8 text-sm text-mute">
        <span>© {new Date().getFullYear()} Skypix <span className="ml-3 text-gold/70">Created by Hann Saravatana</span></span>
        <span className="flex gap-5"><a className="hover:text-gold2" href="/legal#privacy">Privacy</a><a className="hover:text-gold2" href="/legal#terms">Terms</a></span>
      </footer>
    </>
  );
}
