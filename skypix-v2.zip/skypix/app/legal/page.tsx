import Nav from '@/components/Nav';
import AuthMenu from '@/components/AuthMenu';

export const metadata = { title: 'Privacy & Terms — Skypix' };
export default function Legal() {
  const h = 'font-display text-3xl text-gold2';
  return (
    <>
      <Nav auth={<AuthMenu />} />
      <main className="mx-auto max-w-2xl space-y-5 px-4 py-14 text-mute">
        <p className="rounded-lg border border-gold/30 p-3 text-sm">Template text for the site owner. Review it, fill in your details, and have it checked for your jurisdiction before launch.</p>
        <h1 id="privacy" className={h}>Privacy notice</h1>
        <p><b className="text-cream">Your photos leave your device.</b> To enhance a photo, Skypix uploads it to our server, which forwards it to the AI provider (Replicate, running the Real-ESRGAN model). We cannot enhance photos on your device alone.</p>
        <p><b className="text-cream">Retention.</b> Skypix does not write your photo or the result to disk or a database, and stores no photos. Images pass through server memory and are discarded after the response. The AI provider may keep inputs and outputs for a limited time under its own policy; at the time of writing Replicate documents deleting API prediction files after about an hour. Check the provider’s current policy before launch.</p>
        <p><b className="text-cream">Accounts.</b> Signing in is optional unless the owner turns it on. Google handles authentication; Skypix never receives your password. If you sign in we store your Google account ID, email address, name, first and last sign-in time, and whether the owner has restricted the account. Your profile picture is shown from Google and not stored. For each enhancement we record the time, chosen size, face-restoration on/off, outcome and any error message, linked to your account if signed in, never the photo. The owner can view this. Sessions use a secure cookie for 7 days; Sign out ends it.</p>
        <p><b className="text-cream">Training.</b> Skypix does not use your photos to train AI models. Your server logs record request metadata (such as IP address for rate limiting), not image content.</p>
        <h1 id="terms" className={h}>Terms of service</h1>
        <p>Upload only photos you own or have permission to edit. Do not upload unlawful content or content that exploits or harms others. Results are produced by AI and may contain artefacts; Skypix gives no guarantee that detail missing from the original can be restored. The service is provided as is, may be rate-limited, and may change or stop at any time. You are responsible for how you use the enhanced images.</p>
      </main>
    </>
  );
}
