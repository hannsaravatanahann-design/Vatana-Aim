import { NextRequest, NextResponse } from 'next/server';
import sharp from 'sharp';
import { getProvider, ProviderError } from '@/lib/provider';
import { RESOLUTIONS, ResKey, targetSize } from '@/lib/resolutions';
import { getUser } from '@/lib/session';
import { getBool, getNum, recordJob } from '@/lib/db';
import { clientIp, dailyBudgetExceeded, limited, sniff } from '@/lib/security';

export const runtime = 'nodejs';
export const maxDuration = 60;
const MAX_INPUT_EDGE = 1600; // keeps provider GPU memory use safe; larger photos are reduced before AI processing

const fail = (error: string, status: number, retryable = false) => NextResponse.json({ error, retryable }, { status });

export async function POST(req: NextRequest) {
  if (limited(`enh:${clientIp(req)}`, getNum('rate_limit_per_10_min', Number(process.env.RATE_LIMIT_PER_10_MIN ?? 8))))
    return fail('Too many requests. Please wait a few minutes and try again.', 429, true);
  if (!getBool('enhancement_enabled', true)) return fail('Enhancement is temporarily paused. Please try again later.', 503);
  const user = await getUser();
  if (!user && getBool('require_sign_in', process.env.REQUIRE_SIGN_IN === 'true')) return fail('Please sign in with Google to enhance photos.', 401);

  let form: FormData;
  try { form = await req.formData(); } catch { return fail('Invalid upload.', 400); }
  const file = form.get('file');
  const resKey = String(form.get('resolution') ?? '1080p') as ResKey;
  const face = form.get('face') === 'true';
  if (!(file instanceof File)) return fail('No photo was uploaded.', 400);
  if (!RESOLUTIONS.some((r) => r.key === resKey)) return fail('Unknown resolution.', 400);
  const maxBytes = Number(process.env.MAX_UPLOAD_MB ?? 10) * 1024 * 1024;
  if (file.size > maxBytes) return fail(`That photo is larger than ${process.env.MAX_UPLOAD_MB ?? 10} MB.`, 413);

  const buf = Buffer.from(await file.arrayBuffer());
  if (!sniff(buf)) return fail('Only real JPG, PNG or WebP photos are supported.', 415);

  let meta: sharp.Metadata, input: Buffer;
  try {
    const img = sharp(buf, { limitInputPixels: 100_000_000 }).rotate();
    meta = await sharp(buf).rotate().metadata();
    input = await img.resize(MAX_INPUT_EDGE, MAX_INPUT_EDGE, { fit: 'inside', withoutEnlargement: true })
      .flatten({ background: '#ffffff' }).jpeg({ quality: 95 }).toBuffer();
  } catch { return fail('That file could not be read as an image.', 400); }

  const { width: iw, height: ih } = await sharp(input).metadata();
  const swap = (meta.orientation ?? 1) >= 5;
  const [ow, oh] = swap ? [meta.height!, meta.width!] : [meta.width!, meta.height!];
  const target = targetSize(ow, oh, resKey);
  const need = Math.max(target.w, target.h) / Math.max(iw!, ih!);
  const provider = getProvider();
  const aiScale = Math.min(provider.capabilities.maxScalePerPass, Math.max(2, Math.ceil(need)));
  const resample = Math.max(target.w, target.h) / (Math.max(iw!, ih!) * aiScale);

  if (dailyBudgetExceeded()) return fail('Skypix has reached its daily processing limit. Please try again tomorrow.', 503);
  try {
    const id = await provider.start(input, 'image/jpeg', { scale: aiScale, faceEnhance: face });
    recordJob(id, user?.id ?? null, resKey, face);
    return NextResponse.json({ id, target, aiScale, inputReducedTo: { w: iw, h: ih }, resampleFactor: Number(resample.toFixed(2)) });
  } catch (e) {
    const err = e instanceof ProviderError ? e : new ProviderError('Unexpected error.');
    recordJob(`failed-${crypto.randomUUID()}`, user?.id ?? null, resKey, face, 'failed', err.message);
    return fail(err.message, err.status === 429 ? 429 : 502, err.retryable);
  }
}
