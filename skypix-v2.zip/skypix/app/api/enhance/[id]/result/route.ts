import { NextRequest, NextResponse } from 'next/server';
import sharp from 'sharp';
import { getProvider, ProviderError } from '@/lib/provider';
import { clientIp, limited } from '@/lib/security';

export const runtime = 'nodejs';
export const maxDuration = 60;

/** Downloads the provider's real AI output and fits it to the exact requested dimensions (Lanczos).
 *  Nothing is written to disk; the buffer is streamed back and discarded. */
export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  if (!/^[a-z0-9]{8,64}$/.test(params.id)) return NextResponse.json({ error: 'Bad id' }, { status: 400 });
  if (limited(`res:${clientIp(req)}`, 30)) return NextResponse.json({ error: 'Too many requests.' }, { status: 429 });
  const w = Number(req.nextUrl.searchParams.get('w')), h = Number(req.nextUrl.searchParams.get('h'));
  if (!(w >= 1 && h >= 1 && w <= 7680 && h <= 7680)) return NextResponse.json({ error: 'Bad size' }, { status: 400 });
  try {
    const s = await getProvider().status(params.id);
    if (s.state !== 'succeeded' || !s.outputUrl) return NextResponse.json({ error: s.error ?? 'Result not ready.' }, { status: 409 });
    const r = await fetch(s.outputUrl, { signal: AbortSignal.timeout(45_000) });
    if (!r.ok) throw new ProviderError('Could not download the enhanced image.');
    const src = Buffer.from(await r.arrayBuffer());
    const pipe = sharp(src, { limitInputPixels: 400_000_000 }).resize(w, h, { fit: 'fill', kernel: 'lanczos3' });
    const png = w * h <= 3840 * 2160 / 3; // PNG up to ~2.7 MP; JPEG q92 above to keep files practical
    const out = png ? await pipe.png({ compressionLevel: 6 }).toBuffer() : await pipe.jpeg({ quality: 92, mozjpeg: true }).toBuffer();
    return new NextResponse(new Uint8Array(out), { headers: { 'Content-Type': png ? 'image/png' : 'image/jpeg', 'Cache-Control': 'no-store' } });
  } catch (e) {
    const err = e instanceof ProviderError ? e : new ProviderError('Could not prepare the result.');
    return NextResponse.json({ error: err.message }, { status: 502 });
  }
}
