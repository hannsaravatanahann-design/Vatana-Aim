import { NextRequest, NextResponse } from 'next/server';
import { finishJob } from '@/lib/db';
import { getProvider, ProviderError } from '@/lib/provider';

export const runtime = 'nodejs';
export async function GET(_: NextRequest, { params }: { params: { id: string } }) {
  if (!/^[a-z0-9]{8,64}$/.test(params.id)) return NextResponse.json({ error: 'Bad id' }, { status: 400 });
  try {
    const s = await getProvider().status(params.id);
    if (s.state !== 'processing') finishJob(params.id, s.state, s.error);
    return NextResponse.json({ state: s.state, error: s.error });
  } catch (e) {
    const err = e instanceof ProviderError ? e : new ProviderError('Unexpected error.');
    return NextResponse.json({ error: err.message, retryable: err.retryable }, { status: err.status === 429 ? 429 : 502 });
  }
}
