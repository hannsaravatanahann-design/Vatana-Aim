import { NextRequest, NextResponse } from 'next/server';
import { isAdminEmail } from '@/auth';
import { getUser } from '@/lib/session';
import { getBool, getDb, getNum, setSetting } from '@/lib/db';
import { clientIp, limited } from '@/lib/security';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
const json = (d: unknown, status = 200) => NextResponse.json(d, { status, headers: { 'Cache-Control': 'no-store' } });

/** Every admin endpoint calls this first: rate limit, same-origin for writes, then a server-side admin check. */
async function guard(req: NextRequest, write = false) {
  if (limited(`adm:${clientIp(req)}`, 120, 60_000)) return json({ error: 'Too many requests' }, 429);
  if (write) { const o = req.headers.get('origin'); if (!o || new URL(o).host !== req.headers.get('host')) return json({ error: 'Bad origin' }, 403); }
  const u = await getUser();
  if (!u) return json({ error: 'Sign in required' }, 401);
  if (!u.isAdmin) return json({ error: 'Forbidden' }, 403);
  return null;
}
const settings = () => ({
  enhancement_enabled: getBool('enhancement_enabled', true),
  require_sign_in: getBool('require_sign_in', process.env.REQUIRE_SIGN_IN === 'true'),
  max_jobs_per_day: getNum('max_jobs_per_day', Number(process.env.MAX_JOBS_PER_DAY ?? 300)),
  rate_limit_per_10_min: getNum('rate_limit_per_10_min', Number(process.env.RATE_LIMIT_PER_10_MIN ?? 8)),
});

export async function GET(req: NextRequest, { params }: { params: { section: string } }) {
  const denied = await guard(req); if (denied) return denied;
  const d = getDb();
  switch (params.section) {
    case 'overview': {
      const by = Object.fromEntries((d.prepare('SELECT status, COUNT(*) n FROM jobs GROUP BY status').all() as { status: string; n: number }[]).map((r) => [r.status, r.n]));
      return json({
        users: (d.prepare('SELECT COUNT(*) n FROM users').get() as { n: number }).n,
        jobs: by, jobsLast24h: (d.prepare('SELECT COUNT(*) n FROM jobs WHERE created_at > ?').get(Date.now() - 864e5) as { n: number }).n,
        recentFailures: d.prepare("SELECT created_at, resolution, error FROM jobs WHERE status='failed' ORDER BY created_at DESC LIMIT 10").all(),
        config: {
          aiProviderConfigured: !!process.env.AI_PROVIDER_API_KEY && process.env.AI_PROVIDER_API_KEY !== 'your_replicate_token' && process.env.AI_PROVIDER_API_KEY !== 'your_api_key_here',
          googleAuthConfigured: !!(process.env.AUTH_SECRET && process.env.AUTH_GOOGLE_ID && process.env.AUTH_GOOGLE_SECRET),
          adminEmailsConfigured: (process.env.ADMIN_EMAILS ?? '').trim().length > 0,
          provider: process.env.AI_PROVIDER ?? 'replicate',
        },
      });
    }
    case 'users':
      return json(d.prepare('SELECT u.id, u.email, u.name, u.created_at, u.last_login, u.blocked, (SELECT COUNT(*) FROM jobs j WHERE j.user_id=u.id) jobs FROM users u ORDER BY u.created_at DESC LIMIT 500').all()
        .map((r) => ({ ...(r as object), isAdmin: isAdminEmail((r as { email: string }).email) })));
    case 'jobs':
      return json(d.prepare("SELECT j.created_at, j.resolution, j.face, j.status, j.error, COALESCE(u.email,'Guest') who FROM jobs j LEFT JOIN users u ON u.id=j.user_id ORDER BY j.created_at DESC LIMIT 50").all());
    case 'settings': return json(settings());
    default: return json({ error: 'Not found' }, 404);
  }
}

export async function PUT(req: NextRequest, { params }: { params: { section: string } }) {
  const denied = await guard(req, true); if (denied) return denied;
  if (params.section !== 'settings') return json({ error: 'Not found' }, 404);
  const b = await req.json().catch(() => null);
  const int = (v: unknown, lo: number, hi: number) => typeof v === 'number' && Number.isInteger(v) && v >= lo && v <= hi;
  if (!b || typeof b.enhancement_enabled !== 'boolean' || typeof b.require_sign_in !== 'boolean' || !int(b.max_jobs_per_day, 0, 100000) || !int(b.rate_limit_per_10_min, 1, 1000))
    return json({ error: 'Invalid settings' }, 400);
  setSetting('enhancement_enabled', b.enhancement_enabled ? '1' : '0');
  setSetting('require_sign_in', b.require_sign_in ? '1' : '0');
  setSetting('max_jobs_per_day', String(b.max_jobs_per_day));
  setSetting('rate_limit_per_10_min', String(b.rate_limit_per_10_min));
  return json(settings());
}

export async function PATCH(req: NextRequest, { params }: { params: { section: string } }) {
  const denied = await guard(req, true); if (denied) return denied;
  if (params.section !== 'users') return json({ error: 'Not found' }, 404);
  const b = await req.json().catch(() => null);
  if (!b || typeof b.id !== 'string' || b.id.length > 64 || typeof b.blocked !== 'boolean') return json({ error: 'Invalid request' }, 400);
  const row = getDb().prepare('SELECT email FROM users WHERE id=?').get(b.id) as { email: string } | undefined;
  if (!row) return json({ error: 'User not found' }, 404);
  if (isAdminEmail(row.email)) return json({ error: 'Administrators cannot be restricted.' }, 400);
  getDb().prepare('UPDATE users SET blocked=? WHERE id=?').run(b.blocked ? 1 : 0, b.id);
  return json({ ok: true });
}
