'use client';
import { useCallback, useEffect, useRef, useState } from 'react';
import { RESOLUTIONS, ResKey, targetSize } from '@/lib/resolutions';
import Compare from './Compare';

const MAX_MB = 10;
const OK = ['image/jpeg', 'image/png', 'image/webp'];
const fmt = (b: number) => (b > 1048576 ? `${(b / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(b / 1024))} KB`);
type Phase = 'idle' | 'ready' | 'working' | 'done' | 'error';
type Result = { url: string; blob: Blob; w: number; h: number; note: string };

export default function Enhancer({ locked = false, signInSlot }: { locked?: boolean; signInSlot?: React.ReactNode }) {
  const [file, setFile] = useState<File | null>(null);
  const [origUrl, setOrigUrl] = useState('');
  const [dims, setDims] = useState({ w: 0, h: 0 });
  const [res, setRes] = useState<ResKey>('1080p');
  const [face, setFace] = useState(false);
  const [phase, setPhase] = useState<Phase>('idle');
  const [msg, setMsg] = useState('');
  const [error, setError] = useState('');
  const [retryable, setRetryable] = useState(false);
  const [step, setStep] = useState('Preparing Your Photo…');
  const [result, setResult] = useState<Result | null>(null);
  const [dialog, setDialog] = useState(false);
  const [fallback, setFallback] = useState(false);
  const [drag, setDrag] = useState(false);
  const abort = useRef<AbortController | null>(null);
  const input = useRef<HTMLInputElement>(null);

  useEffect(() => () => { abort.current?.abort(); }, []);

  const clearResult = (r: Result | null) => r && URL.revokeObjectURL(r.url);

  const reset = useCallback(() => {
    abort.current?.abort();
    if (origUrl) URL.revokeObjectURL(origUrl);
    clearResult(result);
    setFile(null); setOrigUrl(''); setResult(null); setPhase('idle'); setError(''); setMsg(''); setDialog(false); setFallback(false);
    if (input.current) input.current.value = '';
  }, [origUrl, result]);

  function pick(f?: File | null) {
    if (!f) return;
    if (!OK.includes(f.type)) return setError(`“${f.name}” is not supported. Choose a JPG, PNG or WebP photo.`), setPhase(file ? phase : 'idle');
    if (f.size > MAX_MB * 1048576) return setError(`That photo is ${fmt(f.size)}. The limit is ${MAX_MB} MB.`);
    const url = URL.createObjectURL(f);
    const img = new Image();
    img.onload = () => {
      if (origUrl) URL.revokeObjectURL(origUrl);
      clearResult(result);
      setResult(null); setFile(f); setOrigUrl(url); setDims({ w: img.naturalWidth, h: img.naturalHeight });
      setPhase('ready'); setError(''); setMsg('');
    };
    img.onerror = () => { URL.revokeObjectURL(url); setError('That file could not be opened as an image.'); };
    img.src = url;
  }

  async function enhance() {
    if (!file) return;
    const ac = new AbortController(); abort.current = ac;
    clearResult(result); setResult(null); setPhase('working'); setError(''); setMsg(''); setStep('Preparing Your Photo…');
    try {
      const fd = new FormData();
      fd.append('file', file); fd.append('resolution', res); fd.append('face', String(face));
      const r = await fetch('/api/enhance', { method: 'POST', body: fd, signal: ac.signal });
      const job = await r.json().catch(() => ({}));
      if (!r.ok) throw Object.assign(new Error(job.error || 'Upload failed.'), { retryable: !!job.retryable });

      setStep('Enhancing Image Quality…');
      const t0 = Date.now();
      for (;;) {
        if (Date.now() - t0 > 4 * 60_000) throw Object.assign(new Error('Processing took too long. Please try again.'), { retryable: true });
        await new Promise((ok) => setTimeout(ok, 2000));
        const s = await fetch(`/api/enhance/${job.id}`, { signal: ac.signal });
        const st = await s.json().catch(() => ({}));
        if (!s.ok) { if (s.status === 429) continue; throw Object.assign(new Error(st.error || 'Status check failed.'), { retryable: true }); }
        if (st.state === 'succeeded') break;
        if (st.state === 'failed') throw Object.assign(new Error(st.error || 'The AI provider could not process this photo.'), { retryable: true });
      }

      setStep('Preparing Your Result…');
      const out = await fetch(`/api/enhance/${job.id}/result?w=${job.target.w}&h=${job.target.h}`, { signal: ac.signal });
      if (!out.ok) throw Object.assign(new Error((await out.json().catch(() => ({}))).error || 'Could not fetch the result.'), { retryable: true });
      const blob = await out.blob();
      const bmp = await createImageBitmap(blob);
      const note = `AI upscaled ×${job.aiScale}` + (job.inputReducedTo.w < dims.w && job.inputReducedTo.h <= dims.h && Math.max(dims.w, dims.h) > 1600 ? ' (photo reduced to 1600 px before AI processing)' : '') +
        (job.resampleFactor > 1.01 ? `; then resampled ×${job.resampleFactor} to reach the selected size. The final step adds pixels, not new detail.` : '.');
      setResult({ url: URL.createObjectURL(blob), blob, w: bmp.width, h: bmp.height, note });
      bmp.close(); setPhase('done');
    } catch (e: any) {
      if (e?.name === 'AbortError') return;
      setError(e?.message || 'Something went wrong.'); setRetryable(e?.retryable !== false); setPhase('error');
    }
  }

  async function save() {
    if (!result) return;
    setDialog(false); setMsg('');
    const ext = result.blob.type === 'image/png' ? 'png' : 'jpg';
    const name = `skypix-enhanced.${ext}`;
    const f = new File([result.blob], name, { type: result.blob.type });
    const ua = navigator.userAgent;
    const ios = /iPhone|iPad|iPod/.test(ua) || (ua.includes('Macintosh') && navigator.maxTouchPoints > 1);
    try {
      if (ios) {
        if (navigator.canShare?.({ files: [f] })) {
          await navigator.share({ files: [f], title: 'Skypix enhanced photo' });
          return setMsg('Share sheet opened. Choose “Save Image” to add the photo to Photos.');
        }
        return setFallback(true);
      }
      const a = document.createElement('a');
      a.href = result.url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
      setMsg(`Download requested as ${name}. Check your browser’s downloads if you don’t see it.`);
    } catch (e: any) {
      if (e?.name === 'AbortError') setMsg('Saving was cancelled. Your enhanced photo is still here.');
      else setFallback(true);
    }
  }

  const target = file ? targetSize(dims.w, dims.h, res) : null;
  const card = 'rounded-2xl border border-gold/25 bg-panel p-5 sm:p-8';
  const primary = 'min-h-12 rounded-xl bg-gold px-6 font-semibold text-ink transition hover:bg-gold2 disabled:opacity-50';
  const ghost = 'min-h-12 rounded-xl border border-gold/40 px-5 text-cream hover:bg-gold/10';

  if (locked) return (
    <div className={`${card} text-center`}>
      <h3 className="font-display text-3xl text-gold2">Sign in to enhance photos</h3>
      <p className="mx-auto mt-3 max-w-md text-mute">Enhancement on this site needs a Google account, so each person’s usage can be kept fair. Google handles the sign-in; Skypix never sees your password.</p>
      <div className="mt-6 flex justify-center">{signInSlot}</div>
    </div>
  );
  return (
    <div className={card}>
      <input ref={input} type="file" accept="image/jpeg,image/png,image/webp" className="sr-only" id="file" onChange={(e) => pick(e.target.files?.[0])} />
      {error && <p role="alert" className="mb-4 rounded-lg border border-red-400/40 bg-red-950/40 p-3 text-sm text-red-200">{error}</p>}

      {phase === 'idle' && (
        <div onDragOver={(e) => { e.preventDefault(); setDrag(true); }} onDragLeave={() => setDrag(false)}
          onDrop={(e) => { e.preventDefault(); setDrag(false); pick(e.dataTransfer.files[0]); }}
          className={`rounded-xl border-2 border-dashed p-8 text-center sm:p-14 ${drag ? 'border-gold2 bg-gold/10' : 'border-gold/40'}`}>
          <h3 className="font-display text-3xl text-gold2 sm:text-4xl">Bring Your Photo Back to Life</h3>
          <p className="mx-auto mt-3 max-w-md text-mute">Upload a photo and let Skypix enhance its quality with AI.</p>
          <button className={`${primary} mt-6`} onClick={() => input.current?.click()}>Upload Photo</button>
          <p className="mt-4 text-xs text-mute">JPG, PNG or WebP, up to {MAX_MB} MB. On desktop you can also drag a photo here.</p>
        </div>
      )}

      {(phase === 'ready' || phase === 'error') && file && (
        <div className="grid gap-6 md:grid-cols-2">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={origUrl} alt="Your uploaded photo" className="max-h-[50vh] w-full rounded-xl bg-black object-contain" />
          <div className="space-y-5">
            <dl className="grid grid-cols-2 gap-3 text-sm">
              <div><dt className="text-mute">Original size</dt><dd>{dims.w} × {dims.h} px</dd></div>
              <div><dt className="text-mute">File size</dt><dd>{fmt(file.size)}</dd></div>
            </dl>
            <label className="block text-sm">Output resolution
              <select value={res} onChange={(e) => setRes(e.target.value as ResKey)} className="mt-1 min-h-12 w-full rounded-lg border border-gold/40 bg-ink px-3 text-cream">
                {RESOLUTIONS.map((r) => { const t = targetSize(dims.w, dims.h, r.key); return <option key={r.key} value={r.key}>{r.label} — {t.w} × {t.h}</option>; })}
              </select>
            </label>
            <label className="flex min-h-11 items-start gap-3 text-sm">
              <input type="checkbox" checked={face} onChange={(e) => setFace(e.target.checked)} className="mt-1 h-5 w-5 accent-[#D9A441]" />
              <span>Face restoration<br /><span className="text-mute">Sharpens faces with a dedicated model (GFPGAN). Off by default; best for portraits.</span></span>
            </label>
            <p className="text-xs text-mute">AI upscaling is always on. Output: {target?.w} × {target?.h} px. Skypix cannot recreate detail that is not in the original photo.</p>
            <div className="flex flex-wrap gap-3">
              <button className={primary} onClick={enhance}>{phase === 'error' && retryable ? 'Try Again' : 'Enhance Photo'}</button>
              <button className={ghost} onClick={reset}>Choose Another Photo</button>
            </div>
          </div>
        </div>
      )}

      {phase === 'working' && (
        <div className="py-10 text-center" role="status" aria-live="polite">
          <p className="font-display text-3xl text-gold2">{step}</p>
          <div className="mx-auto mt-6 h-1.5 w-full max-w-md overflow-hidden rounded bg-ink"><div className="indeterminate h-full w-1/4 rounded bg-gold" /></div>
          <p className="mt-4 text-sm text-mute">This usually takes under a minute. Larger outputs take longer.</p>
          <button className={`${ghost} mt-6`} onClick={() => { abort.current?.abort(); setPhase('ready'); }}>Cancel</button>
        </div>
      )}

      {phase === 'done' && result && file && (
        <div className="space-y-5">
          <Compare original={origUrl} enhanced={result.url} />
          <dl className="grid grid-cols-2 gap-3 text-sm sm:grid-cols-4">
            <div><dt className="text-mute">Original</dt><dd>{dims.w} × {dims.h}</dd></div>
            <div><dt className="text-mute">Enhanced</dt><dd>{result.w} × {result.h}</dd></div>
            <div><dt className="text-mute">Original file</dt><dd>{fmt(file.size)}</dd></div>
            <div><dt className="text-mute">Enhanced file</dt><dd>{fmt(result.blob.size)} ({result.blob.type === 'image/png' ? 'PNG' : 'JPG'})</dd></div>
          </dl>
          <p className="text-xs text-mute">{result.note}</p>
          <div className="flex flex-wrap gap-3">
            <button className={primary} onClick={() => setDialog(true)}>Save the Image</button>
            <button className={ghost} onClick={reset}>Try Another Photo</button>
            <button className={ghost} onClick={() => { clearResult(result); setResult(null); setPhase('ready'); setMsg(''); }}>Change Settings</button>
          </div>
        </div>
      )}

      {msg && <p role="status" className="mt-4 rounded-lg border border-gold/30 bg-gold/10 p-3 text-sm text-gold2">{msg}</p>}

      {dialog && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/70 p-4" role="dialog" aria-modal="true" aria-labelledby="dlg-t" onKeyDown={(e) => e.key === 'Escape' && setDialog(false)}>
          <div className="w-full max-w-sm rounded-2xl border border-gold/40 bg-panel p-6">
            <h3 id="dlg-t" className="font-display text-2xl text-gold2">Save Your Enhanced Photo?</h3>
            <p className="mt-2 text-sm text-mute">Your enhanced photo is ready. Continue to save it to your device.</p>
            <div className="mt-5 flex gap-3">
              <button autoFocus className={`${primary} flex-1`} onClick={save}>Save Image</button>
              <button className={`${ghost} flex-1`} onClick={() => setDialog(false)}>Cancel</button>
            </div>
          </div>
        </div>
      )}

      {fallback && result && (
        <div className="fixed inset-0 z-50 grid place-items-center overflow-auto bg-black/80 p-4" role="dialog" aria-modal="true" aria-label="Save with Safari">
          <div className="w-full max-w-md rounded-2xl border border-gold/40 bg-panel p-5">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={result.url} alt="Enhanced photo" className="max-h-[50vh] w-full rounded-lg object-contain" />
            <p className="mt-3 text-sm text-cream">Your browser can’t open the save sheet directly. Press and hold the photo, then tap <b>Add to Photos</b> (or <b>Save to Photos</b>). You can also use Safari’s Share button.</p>
            <button className={`${ghost} mt-4 w-full`} onClick={() => setFallback(false)}>Close</button>
          </div>
        </div>
      )}
    </div>
  );
}
