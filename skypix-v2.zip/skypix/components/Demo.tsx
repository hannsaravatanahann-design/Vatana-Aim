'use client';
import { useState } from 'react';
import { Temple } from './Logo';

/** Illustration only. It is NOT produced by the AI pipeline; real results come from the Enhancer above/below. */
export default function Demo() {
  const [p, setP] = useState(50);
  const scene = (cls: string, style?: React.CSSProperties) => (
    <div className={`absolute inset-0 bg-gradient-to-b from-[#3a2a14] via-[#7a4f1c] to-[#101114] ${cls}`} style={style}>
      <Temple className="absolute inset-x-0 bottom-0 h-3/4 w-full text-[#0b0b0d]" />
    </div>
  );
  return (
    <figure>
      <div className="relative aspect-[16/8] overflow-hidden rounded-xl border border-gold/30">
        {scene('', { filter: 'blur(4px) contrast(.8) saturate(.6)' })}
        {scene('', { clipPath: `inset(0 0 0 ${p}%)` })}
        <span className="absolute left-2 top-2 rounded bg-black/70 px-2 py-1 text-xs">Low quality</span>
        <span className="absolute right-2 top-2 rounded bg-black/70 px-2 py-1 text-xs text-gold2">Sharp</span>
        <span className="absolute inset-y-0 w-0.5 bg-gold2" style={{ left: `${p}%` }} />
      </div>
      <input type="range" min={0} max={100} value={p} onChange={(e) => setP(Number(e.target.value))} aria-label="Demonstration slider" className="mt-2 h-11 w-full accent-[#D9A441]" />
      <figcaption className="text-xs text-mute"><b className="text-sand">Demonstration only.</b> This is an illustration of the idea, not an AI-processed photo. Upload your own photo to see a real result.</figcaption>
    </figure>
  );
}
