export function Sparkle({ className = '' }: { className?: string }) {
  return <svg viewBox="-12 -12 24 24" className={className} aria-hidden="true"><path d="M0-10Q1-1 10 0 1 1 0 10-1 1-10 0-1-1 0-10z" fill="currentColor" /></svg>;
}

/** Angkor Wat–inspired silhouette: five lotus-bud towers on tiered galleries. Original artwork. */
export function Temple({ className = '' }: { className?: string }) {
  const tower = (cx: number, base: number, h: number) => {
    const y0 = 300 - h, r = base / 2;
    return (
      <g key={cx}>
        <rect x={cx - r} y={y0 + h * 0.55} width={base} height={h * 0.45} />
        <rect x={cx - r * 0.8} y={y0 + h * 0.35} width={base * 0.8} height={h * 0.22} />
        <rect x={cx - r * 0.6} y={y0 + h * 0.22} width={base * 0.6} height={h * 0.15} />
        <path d={`M${cx - r * 0.45} ${y0 + h * 0.23}Q${cx - r * 0.4} ${y0 + h * 0.05} ${cx} ${y0}Q${cx + r * 0.4} ${y0 + h * 0.05} ${cx + r * 0.45} ${y0 + h * 0.23}Z`} />
      </g>
    );
  };
  return (
    <svg viewBox="0 0 1200 320" preserveAspectRatio="xMidYMax slice" className={className} fill="currentColor" aria-hidden="true">
      {tower(600, 120, 230)}{tower(500, 80, 160)}{tower(700, 80, 160)}{tower(410, 64, 115)}{tower(790, 64, 115)}
      <rect x="330" y="268" width="540" height="14" /><rect x="290" y="282" width="620" height="12" /><rect x="240" y="294" width="720" height="26" />
      {[260, 300, 340, 380, 820, 860, 900, 940].map((x) => <rect key={x} x={x} y="296" width="8" height="24" fill="#101114" opacity=".55" />)}
    </svg>
  );
}

export function Logo({ size = 'md' }: { size?: 'md' | 'lg' }) {
  const s = size === 'lg' ? 'h-12' : 'h-9';
  return (
    <span className="inline-flex items-center gap-2.5" aria-label="Skypix">
      <span className={`relative text-gold ${s} aspect-[1.25/1]`}>
        <Temple className="absolute inset-x-0 bottom-0 h-[78%] w-full" />
        <Sparkle className="absolute left-1/2 top-0 h-[34%] -translate-x-1/2 text-gold2" />
      </span>
      <span className={`font-display font-semibold tracking-wide text-gold2 ${size === 'lg' ? 'text-4xl' : 'text-2xl'}`}>Skypix</span>
    </span>
  );
}

/** Simplified Bayon-style serene face on a stone block. */
export function BayonFace({ className = '' }: { className?: string }) {
  return (
    <svg viewBox="0 0 120 150" className={className} role="img" aria-label="Stylised Bayon stone face">
      <rect x="6" y="6" width="108" height="138" rx="10" fill="#191A1F" stroke="#D9A441" strokeOpacity=".5" />
      <path d="M30 40Q60 22 90 40" fill="none" stroke="#D7BD8A" strokeWidth="3" />
      <path d="M32 58q10 7 20 0M68 58q10 7 20 0" fill="none" stroke="#D9A441" strokeWidth="3" strokeLinecap="round" />
      <path d="M60 52v32q-8 6-14 2M60 84q8 6 14 2" fill="none" stroke="#D7BD8A" strokeWidth="3" strokeLinecap="round" />
      <path d="M38 104q22 14 44 0" fill="none" stroke="#F5D58A" strokeWidth="3.5" strokeLinecap="round" />
      <path d="M44 108q16 7 32 0" fill="none" stroke="#D9A441" strokeWidth="2" strokeLinecap="round" />
      <path d="M36 20h48" stroke="#D9A441" strokeOpacity=".6" strokeWidth="2" />
    </svg>
  );
}
