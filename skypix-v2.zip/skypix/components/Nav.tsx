'use client';
import { useState } from 'react';
import { Logo } from './Logo';

const links = [['Home', '/#home'], ['AI Enhancer', '/#enhancer'], ['Features', '/#features'], ['About', '/#about']];
export default function Nav({ auth }: { auth?: React.ReactNode }) {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-40 border-b border-gold/15 bg-ink/90 backdrop-blur">
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3" aria-label="Main">
        <a href="/#home" aria-label="Skypix home"><Logo /></a>
        <ul className="hidden items-center gap-7 md:flex">
          {links.map(([t, h]) => <li key={t}><a className="text-sm text-mute hover:text-gold2" href={h}>{t}</a></li>)}
          <li><a href="/#enhancer" className="rounded-lg bg-gold px-4 py-2 text-sm font-semibold text-ink hover:bg-gold2">Enhance Photo</a></li>
        </ul>
        <div className="flex items-center gap-2">{auth}<button className="grid h-11 w-11 place-items-center rounded-lg border border-gold/40 md:hidden" aria-expanded={open} aria-controls="m" aria-label="Menu" onClick={() => setOpen(!open)}>{open ? '✕' : '☰'}</button></div>
      </nav>
      {open && (
        <ul id="m" className="space-y-1 border-t border-gold/15 px-4 py-3 md:hidden">
          {links.map(([t, h]) => <li key={t}><a onClick={() => setOpen(false)} className="block py-3 text-cream" href={h}>{t}</a></li>)}
          <li><a onClick={() => setOpen(false)} href="/#enhancer" className="block rounded-lg bg-gold py-3 text-center font-semibold text-ink">Enhance Photo</a></li>
        </ul>
      )}
    </header>
  );
}
