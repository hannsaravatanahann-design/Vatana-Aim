import { signOut } from '@/auth';
import { getUser } from '@/lib/session';
import SignInButton from './SignInButton';

export default async function AuthMenu() {
  const u = await getUser();
  if (!u) return <SignInButton compact redirectTo="/" />;
  return (
    <details className="relative">
      <summary className="grid h-11 w-11 cursor-pointer list-none place-items-center overflow-hidden rounded-full border border-gold/60 bg-panel text-gold2" aria-label="Account menu">
        {u.image
          // eslint-disable-next-line @next/next/no-img-element
          ? <img src={u.image} alt="" referrerPolicy="no-referrer" className="h-full w-full object-cover" />
          : <span>{(u.name ?? u.email)[0].toUpperCase()}</span>}
      </summary>
      <div className="absolute right-0 z-50 mt-2 w-64 rounded-xl border border-gold/40 bg-panel p-4 shadow-xl">
        <p className="truncate font-semibold text-cream">{u.name ?? 'Signed in'}</p>
        <p className="truncate text-sm text-mute">{u.email}</p>
        {u.isAdmin && <a href="/admin" className="mt-3 block min-h-11 rounded-lg bg-gold px-3 py-2.5 text-center text-sm font-semibold text-ink">Admin Dashboard</a>}
        <form action={async () => { 'use server'; await signOut({ redirectTo: '/' }); }}>
          <button className="mt-3 min-h-11 w-full rounded-lg border border-gold/40 text-sm text-cream hover:bg-gold/10">Sign out</button>
        </form>
      </div>
    </details>
  );
}
