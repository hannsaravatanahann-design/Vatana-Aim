'use client';
import { useCallback, useEffect, useState } from 'react';
import { Temple } from './Logo';

const TABS = ['Overview', 'Users', 'AI processing', 'Settings', 'Profile'] as const;
const when = (t: number) => new Date(t).toLocaleString();
type Any = any; // eslint-disable-line @typescript-eslint/no-explicit-any

async function api(section: string, init?: RequestInit) {
  const r = await fetch(`/api/admin/${section}`, { ...init, headers: { 'Content-Type': 'application/json' } });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.error || `Request failed (${r.status})`);
  return d;
}
const Card = ({ t, v }: { t: string; v: React.ReactNode }) => <div className="rounded-xl border border-gold/25 bg-panel p-4"><p className="text-xs text-mute">{t}</p><p className="mt-1 font-display text-3xl text-gold2">{v}</p></div>;
const Yes = ({ ok }: { ok: boolean }) => <span className={ok ? 'text-green-400' : 'text-red-300'}>{ok ? 'Configured' : 'Not configured'}</span>;

export default function AdminDashboard({ email, name }: { email: string; name: string | null }) {
  const [tab, setTab] = useState<(typeof TABS)[number]>('Overview');
  const [data, setData] = useState<Any>(null);
  const [jobs, setJobs] = useState<Any[]>([]);
  const [err, setErr] = useState('');
  const [note, setNote] = useState('');

  const load = useCallback(async () => {
    setErr(''); setData(null);
    try {
      if (tab === 'Overview') setData(await api('overview'));
      if (tab === 'Users') setData(await api('users'));
      if (tab === 'AI processing') { setData(await api('overview')); setJobs(await api('jobs')); }
      if (tab === 'Settings') setData(await api('settings'));
    } catch (e: Any) { setErr(e.message); }
  }, [tab]);
  useEffect(() => { load(); }, [load]);

  async function block(id: string, blocked: boolean) {
    try { await api('users', { method: 'PATCH', body: JSON.stringify({ id, blocked }) }); load(); } catch (e: Any) { setErr(e.message); }
  }
  async function save(e: React.FormEvent) {
    e.preventDefault(); setNote('');
    try { setData(await api('settings', { method: 'PUT', body: JSON.stringify(data) })); setNote('Settings saved.'); } catch (x: Any) { setErr(x.message); }
  }
  const th = 'px-2 py-2 text-left font-normal text-mute';
  const td = 'px-2 py-2 align-top';

  return (
    <main className="khmer-pattern relative">
      <Temple className="pointer-events-none absolute inset-x-0 bottom-0 h-40 w-full text-gold/5" />
      <div className="relative mx-auto max-w-6xl px-4 py-8">
        <h1 className="font-display text-4xl text-gold2">Admin Dashboard</h1>
        <div role="tablist" className="mt-4 flex gap-1 overflow-x-auto border-b border-gold/20">
          {TABS.map((t) => <button key={t} role="tab" aria-selected={tab === t} onClick={() => setTab(t)} className={`min-h-11 whitespace-nowrap px-4 text-sm ${tab === t ? 'border-b-2 border-gold text-gold2' : 'text-mute'}`}>{t}</button>)}
        </div>
        {err && <p role="alert" className="mt-4 rounded-lg border border-red-400/40 bg-red-950/40 p-3 text-sm text-red-200">{err}</p>}
        {!data && !err && tab !== 'Profile' && <p className="mt-6 text-mute">Loading…</p>}

        {tab === 'Overview' && data && (
          <section className="mt-6 space-y-6">
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
              <Card t="Registered users" v={data.users} /><Card t="Successful jobs" v={data.jobs.succeeded ?? 0} />
              <Card t="Failed jobs" v={data.jobs.failed ?? 0} /><Card t="Jobs in last 24 h" v={data.jobsLast24h} />
            </div>
            <dl className="grid gap-2 rounded-xl border border-gold/25 bg-panel p-4 text-sm sm:grid-cols-3">
              <div><dt className="text-mute">AI provider ({data.config.provider})</dt><dd><Yes ok={data.config.aiProviderConfigured} /></dd></div>
              <div><dt className="text-mute">Google sign-in</dt><dd><Yes ok={data.config.googleAuthConfigured} /></dd></div>
              <div><dt className="text-mute">Admin allowlist</dt><dd><Yes ok={data.config.adminEmailsConfigured} /></dd></div>
            </dl>
            <p className="text-xs text-mute">Counts cover only jobs since this database was created. A job counts as successful once the provider reports success to the app; jobs whose browser tab closed early may stay “processing”.</p>
            <div><h2 className="font-display text-2xl text-gold2">Recent failures</h2>
              {data.recentFailures.length === 0 ? <p className="mt-2 text-sm text-mute">None recorded.</p> :
                <ul className="mt-2 space-y-1 text-sm">{data.recentFailures.map((f: Any, i: number) => <li key={i} className="text-mute"><span className="text-cream">{when(f.created_at)}</span> · {f.resolution} · {f.error ?? 'No message'}</li>)}</ul>}
            </div>
          </section>
        )}

        {tab === 'Users' && data && (
          <section className="mt-6 overflow-x-auto">
            <table className="w-full min-w-[640px] text-sm"><thead><tr><th className={th}>Email</th><th className={th}>Name</th><th className={th}>Registered</th><th className={th}>Jobs</th><th className={th}>Status</th><th className={th}></th></tr></thead>
              <tbody className="divide-y divide-gold/10">{data.map((u: Any) => (
                <tr key={u.id}><td className={td}>{u.email}</td><td className={td}>{u.name ?? '—'}</td><td className={td}>{when(u.created_at)}</td><td className={td}>{u.jobs}</td>
                  <td className={td}>{u.isAdmin ? 'Admin' : u.blocked ? 'Restricted' : 'Active'}</td>
                  <td className={td}>{!u.isAdmin && <button onClick={() => block(u.id, !u.blocked)} className="min-h-11 rounded-lg border border-gold/40 px-3 hover:bg-gold/10">{u.blocked ? 'Restore' : 'Restrict'}</button>}</td></tr>))}</tbody></table>
            {data.length === 0 && <p className="mt-3 text-mute">No one has signed in yet.</p>}
            <p className="mt-3 text-xs text-mute">Restricting stops that account from signing in or using its session. It does not stop guest use unless “Require sign-in” is on in Settings.</p>
          </section>
        )}

        {tab === 'AI processing' && data && (
          <section className="mt-6 space-y-5">
            <div className="grid gap-3 sm:grid-cols-3"><Card t="Succeeded" v={data.jobs.succeeded ?? 0} /><Card t="Failed" v={data.jobs.failed ?? 0} /><Card t="Still processing" v={data.jobs.processing ?? 0} /></div>
            <p className="rounded-lg border border-gold/25 p-3 text-sm text-mute">Cost: not shown. Skypix does not read billing data from Replicate, so any figure would be invented. See the Billing page in your Replicate dashboard.</p>
            <div className="overflow-x-auto"><table className="w-full min-w-[640px] text-sm"><thead><tr><th className={th}>Time</th><th className={th}>User</th><th className={th}>Size</th><th className={th}>Faces</th><th className={th}>Status</th><th className={th}>Error</th></tr></thead>
              <tbody className="divide-y divide-gold/10">{jobs.map((j, i) => <tr key={i}><td className={td}>{when(j.created_at)}</td><td className={td}>{j.who}</td><td className={td}>{j.resolution}</td><td className={td}>{j.face ? 'Yes' : 'No'}</td><td className={td}>{j.status}</td><td className={td}>{j.error ?? ''}</td></tr>)}</tbody></table>
              {jobs.length === 0 && <p className="mt-3 text-mute">No jobs recorded yet.</p>}</div>
          </section>
        )}

        {tab === 'Settings' && data && (
          <form onSubmit={save} className="mt-6 max-w-md space-y-4">
            <label className="flex min-h-11 items-center gap-3"><input type="checkbox" className="h-5 w-5 accent-[#D9A441]" checked={data.enhancement_enabled} onChange={(e) => setData({ ...data, enhancement_enabled: e.target.checked })} />Enhancement enabled</label>
            <label className="flex min-h-11 items-center gap-3"><input type="checkbox" className="h-5 w-5 accent-[#D9A441]" checked={data.require_sign_in} onChange={(e) => setData({ ...data, require_sign_in: e.target.checked })} />Require Google sign-in to enhance</label>
            <label className="block text-sm">Max jobs per day (whole site)<input type="number" min={0} max={100000} className="mt-1 min-h-11 w-full rounded-lg border border-gold/40 bg-ink px-3" value={data.max_jobs_per_day} onChange={(e) => setData({ ...data, max_jobs_per_day: Number(e.target.value) })} /></label>
            <label className="block text-sm">Max requests per IP per 10 minutes<input type="number" min={1} max={1000} className="mt-1 min-h-11 w-full rounded-lg border border-gold/40 bg-ink px-3" value={data.rate_limit_per_10_min} onChange={(e) => setData({ ...data, rate_limit_per_10_min: Number(e.target.value) })} /></label>
            <button className="min-h-12 rounded-xl bg-gold px-6 font-semibold text-ink">Save settings</button>
            {note && <p role="status" className="text-sm text-gold2">{note}</p>}
            <p className="text-xs text-mute">API keys and OAuth secrets live only in server environment variables and cannot be viewed or changed here.</p>
          </form>
        )}

        {tab === 'Profile' && (
          <section className="mt-6 text-sm"><p className="text-mute">Signed in as</p><p className="text-lg text-cream">{name ?? 'Administrator'}</p><p className="text-gold2">{email} <span className="text-mute">(verified by Google)</span></p>
            <p className="mt-3 text-mute">Use the account menu in the header to sign out.</p></section>
        )}
      </div>
    </main>
  );
}
