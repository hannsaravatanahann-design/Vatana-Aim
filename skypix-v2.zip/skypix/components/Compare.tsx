'use client';
import { useRef, useState } from 'react';

export default function Compare({ original, enhanced }: { original: string; enhanced: string }) {
  const [pos, setPos] = useState(50);
  const [zoom, setZoom] = useState(1);
  const box = useRef<HTMLDivElement>(null);
  const wrap = useRef<HTMLDivElement>(null);
  const dragging = useRef(false);
  const move = (x: number) => {
    const r = wrap.current!.getBoundingClientRect();
    setPos(Math.min(100, Math.max(0, ((x - r.left) / r.width) * 100)));
  };
  const btn = 'min-h-11 min-w-11 rounded-lg border border-gold/40 px-3 text-sm text-cream hover:bg-gold/10';
  return (
    <div>
      <div ref={box} className="max-h-[70vh] overflow-auto rounded-xl border border-gold/30 bg-black">
        <div ref={wrap} className="relative select-none" style={{ width: `${zoom * 100}%` }}>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={enhanced} alt="Enhanced photo" className="block h-auto w-full" draggable={false} />
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={original} alt="Original photo" draggable={false} className="absolute inset-0 h-full w-full object-fill"
            style={{ clipPath: `inset(0 ${100 - pos}% 0 0)` }} />
          <span className="absolute left-2 top-2 rounded bg-black/70 px-2 py-1 text-xs text-cream">Original</span>
          <span className="absolute right-2 top-2 rounded bg-black/70 px-2 py-1 text-xs text-gold2">Enhanced</span>
          <div className="absolute inset-y-0 flex w-11 -translate-x-1/2 cursor-ew-resize items-center justify-center" style={{ left: `${pos}%`, touchAction: 'none' }}
            onPointerDown={(e) => { dragging.current = true; e.currentTarget.setPointerCapture(e.pointerId); }}
            onPointerMove={(e) => dragging.current && move(e.clientX)}
            onPointerUp={() => (dragging.current = false)} onPointerCancel={() => (dragging.current = false)}>
            <span className="absolute inset-y-0 w-0.5 bg-gold2" />
            <span className="relative grid h-9 w-9 place-items-center rounded-full border-2 border-gold2 bg-ink text-gold2" aria-hidden="true">↔</span>
          </div>
        </div>
      </div>
      <div className="mt-3 flex flex-wrap items-center gap-2">
        <label className="flex flex-1 items-center gap-3 text-sm text-mute" style={{ minWidth: 200 }}>
          Compare
          <input type="range" min={0} max={100} value={pos} onChange={(e) => setPos(Number(e.target.value))} className="h-11 w-full accent-[#D9A441]" aria-label="Comparison position, original on the left" />
        </label>
        <button className={btn} onClick={() => setZoom((z) => Math.max(1, +(z - 0.5).toFixed(1)))} aria-label="Zoom out">−</button>
        <span className="w-12 text-center text-sm text-mute" aria-live="polite">{Math.round(zoom * 100)}%</span>
        <button className={btn} onClick={() => setZoom((z) => Math.min(4, +(z + 0.5).toFixed(1)))} aria-label="Zoom in">+</button>
        <button className={btn} onClick={() => { setZoom(1); setPos(50); box.current?.scrollTo(0, 0); }}>Reset view</button>
      </div>
    </div>
  );
}
