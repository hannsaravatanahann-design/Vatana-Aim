import { signIn } from '@/auth';

export function GoogleG() {
  return (
    <svg viewBox="0 0 48 48" className="h-5 w-5" aria-hidden="true">
      <path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9.1 3.6l6.8-6.8C35.8 2.4 30.3 0 24 0 14.6 0 6.5 5.4 2.6 13.2l7.9 6.1C12.4 13.6 17.7 9.5 24 9.5z" />
      <path fill="#4285F4" d="M46.5 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.7c-.6 3-2.3 5.5-4.8 7.2l7.5 5.8c4.4-4.1 7.1-10.1 7.1-17.5z" />
      <path fill="#FBBC05" d="M10.5 28.7a14.500 14.500 0 010-9.4l-7.9-6.100A24 24 0 000 24c0 3.900.9 7.500 2.600 10.800l7.900-6.100z" />
      <path fill="#34A853" d="M24 48c6.500 0 11.900-2.100 15.900-5.800l-7.500-5.800c-2.100 1.400-4.800 2.300-8.400 2.300-6.300 0-11.600-4.100-13.500-9.800l-7.900 6.100C6.500 42.600 14.600 48 24 48z" />
    </svg>
  );
}

/** Starts Google's official OAuth flow. The redirect target is restricted to same-site paths. */
export default function SignInButton({ redirectTo = '/', compact = false }: { redirectTo?: string; compact?: boolean }) {
  const to = redirectTo.startsWith('/') && !redirectTo.startsWith('//') ? redirectTo : '/';
  return (
    <form action={async () => { 'use server'; await signIn('google', { redirectTo: to }); }}>
      <button className={`inline-flex min-h-11 items-center gap-2.5 rounded-xl border border-gold/50 bg-cream px-4 font-semibold text-ink hover:bg-white ${compact ? 'text-sm' : 'min-h-12 px-6'}`}>
        <GoogleG />
        {compact ? <><span className="hidden sm:inline">Sign in with Google</span><span className="sm:hidden">Sign in</span></> : 'Sign in with Google'}
      </button>
    </form>
  );
}
